<!doctype html> 
<html style="height:100%;" <?php language_attributes(); ?>>