<?php
get_header(); ?>

<head> 
    <meta charset="<?php bloginfo( 'charset' ); ?>"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <meta name="keywords" content="pinegrow, blocks, bootstrap" />
    <meta name="description" content="My new website" />
    <link rel="shortcut icon" href="<?php echo esc_url( get_template_directory_uri() ); ?>/ico/favicon.png"> 
    <!-- Core CSS -->                  
    <!-- Style Library -->         
    <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->         
    <!--[if lt IE 9]>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5shiv.js"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/respond.min.js"></script>
<![endif]-->         
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <?php wp_head(); ?>
</head>     
<body data-spy="scroll" data-target="nav">
    <header class="site-header">
        <div class="container">
            <div class="site-brand ">
                <a class="navbar-brand" href="https://gandengtangan.org">
                    <div class="site-with-image">
                        <img class="site-logo" src="https://gandengtangan.org/assets/img/logo.png" alt="Homepage GandengTangan.org" title="Situs CrowdLending Pinjaman Dana Untuk Usaha | GandengTangan.org">
                    </div>
                </a>
            </div>
            <div class="site-quicknav pull-right">
                <ul class="nav navbar-right">
                    <li class="dropdown language">
                        <a href="#" class="dropdown-toggle " data-toggle="dropdown" rel="nofollow" aria-expanded="true"><i><img src="https://gandengtangan.org/assets/img/id.jpg" alt="id"></i><span class="topnav-label"><span><?php _e( 'ID', 'blog' ); ?></span></span><i class="fa fa-angle-down"></i></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="?lang=id" title="Bahasa Indonesia">
                                    <?php _e( 'Bahasa Indonesia', 'blog' ); ?>
                                </a>
                            </li>
                            <li>
                                <a href="?lang=en" title="English">
                                    <?php _e( 'English', 'blog' ); ?>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="signup">
                        <a href="https://gandengtangan.org/register">
                            <?php _e( 'Daftar', 'blog' ); ?>
                        </a>
                    </li>
                    <li class="login">
                        <a href="https://gandengtangan.org/login">
                            <?php _e( 'Masuk', 'blog' ); ?>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- Default snippet for navigation -->
            <nav class="main-navigation ">
                <button type="button" class="menu-toggle">
                    <i class="fa fa-bars"></i>
                </button>
                <div class="desktop-navigation">
                    <ul class="menu">
                        <li class="menu-item">
                            <a href="https://gandengtangan.org">
                                <?php _e( 'Beranda', 'blog' ); ?>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="https://gandengtangan.org/browse">
                                <?php _e( 'Pinjamkan Dana', 'blog' ); ?>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="https://gandengtangan.org/borrow">
                                <?php _e( 'Ajukan Usaha', 'blog' ); ?>
                            </a>
                        </li>
                    </ul>                         
                    <!-- .menu -->
                </div>                     
                <!-- .desktop-navigation -->
            </nav>                 
            <!-- .main-navigation -->
            <nav class="mobile-navigation" style="display: none;">
                <ul class="menu">
                    <li class="menu-item">
                        <a href="https://gandengtangan.org">
                            <?php _e( 'Beranda', 'blog' ); ?>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a href="https://gandengtangan.org/browse">
                            <?php _e( 'Pinjamkan Dana', 'blog' ); ?>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a href="https://gandengtangan.org/borrow">
                            <?php _e( 'Ajukan Usaha', 'blog' ); ?>
                        </a>
                    </li>
                </ul>
            </nav>                 
            <!-- .mobile-navigation -->
        </div>
        <nav class="navbar navbar-default nav2" role="navigation">
            <div class="container-fluid nav2">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only"><?php _e( 'Toggle navigation', 'blog' ); ?></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li class="active">
                            <a href="#">
                                <?php _e( 'Stories', 'blog' ); ?>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <?php _e( 'Videos', 'blog' ); ?>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <?php _e( 'Photos', 'blog' ); ?>
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container-fluid -->
        </nav>
    </header>
    <main>
        <div class="fullwidth-block ">
            <div class="container text-left" id="head-thub">
                <h3><h3 class="black"><b><?php _e( 'Korporasi Juga Bisa&nbsp;Jadi Agen Perubahan&nbsp;lewat website&nbsp;', 'blog' ); ?><br></b><b style="color: inherit; line-height: 1.1;"><?php _e( 'GandengTangan.org', 'blog' ); ?></b></h3></h3>
                <a class="btn bg-tan-hover black" id="btn-head">
                    <?php _e( 'Daftar Sekarang', 'blog' ); ?>
                </a>
            </div>
        </div>
        <section class="content-block team-1 team-1-1">
            <div class="container">
                <div class="underlined-title">
                    <h1 class="text-center main-txt"><?php echo get_theme_mod( 'blocks_team_1_1_title', __( 'INFO TERBARU', 'blog' ) ); ?></h1>
                </div>
                <div class="row">
                    <?php if ( have_posts() ) : ?>
                        <?php $item_number = 0; ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                            <div class="col-sm-4 team-member-wrap">
                                <div class="team-member min-height-xs-400px card-blog">
                                    <?php the_post_thumbnail( 'large', array(
                                            'class' => 'img-responsive'
                                    ) ); ?>
                                    <div class="team-details">
                                        <h4><?php the_title(); ?></h4>
                                        <small><?php _e( 'Diposting Oleh:', 'blog' ); ?> <?php the_author(); ?></small>
                                        <?php the_content(); ?>
                                        <!-- /.social -->
                                    </div>
                                </div>
                            </div>
                            <?php $item_number++; ?>
                            <?php if( $item_number % 3 == 0 ) echo '<div class="clearfix visible-sm-block visible-md-block visible-lg-block"></div>'; ?>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    <!-- /.team-member-wrap -->
                    <!-- /.team-member-wrap -->
                    <!-- /.team-member-wrap -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </section>
        <div class="next-page">
            <button class="btn-next bg-river-hover white-hover" style="display: block; margin: 0 auto; data-pg-id=" 839"">
                <?php _e( 'POSTINGAN LAINNYA', 'blog' ); ?>
            </button>
        </div>
    </main>
    <footer class="site-footer footer">
        <div class="container">
            <div class="top-footer">
                <div class="row">
                    <div class="col-md-8">
                        <h2><?php _e( 'Tentang Gandeng Tangan', 'blog' ); ?></h2>
                        <p><?php _e( 'GandengTangan adalah wadah kolaborasi bagi pemilik usaha', 'blog' ); ?><br><?php _e( 'yang membutuhkan modal dengan publik yang tulus ingin membantu dengan', 'blog' ); ?><br><?php _e( 'memberikan pinjaman. GandengTangan hadir untuk', 'blog' ); ?><br><?php _e( 'menjembatani keduanya agar dapat bergandengan tangan untuk', 'blog' ); ?><br><?php _e( 'menciptakan dampak baik bagi Indonesia.', 'blog' ); ?></p>
                    </div>
                    <div class="col-md-2">
                        <h2><?php _e( 'Info Lain', 'blog' ); ?></h2>
                        <ul>
                            <li>
                                <a href="#">
                                    <?php _e( 'Tentang kami', 'blog' ); ?>
                                </a>
                            </li>
                            <li>
                                <a href="#" target="_blank">
                                    <?php _e( 'Blog', 'blog' ); ?>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <?php _e( 'Faq', 'blog' ); ?>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <?php _e( 'Privacy', 'blog' ); ?>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <?php _e( 'Syarat dan ketentuan', 'blog' ); ?>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <?php _e( 'Kontak', 'blog' ); ?>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-2">
                        <h2><?php _e( 'Follow Us', 'blog' ); ?></h2>
                        <ul>
                            <li>
                                <a href="https://facebook.com/gandengtanganorg">
                                    <i class="fa fa-facebook"></i>
                                    <?php _e( 'facebook', 'blog' ); ?>
                                </a>
                            </li>
                            <li>
                                <a href="https://twitter.com/gandeng_tangan">
                                    <i class="fa fa-twitter"></i>
                                    <?php _e( 'Twitter', 'blog' ); ?>
                                </a>
                            </li>
                            <li>
                                <a href="https://instagram.com/gandengtangan">
                                    <i class="fa fa-instagram"></i>
                                    <?php _e( 'Instagram', 'blog' ); ?>
                                </a>
                            </li>
                            <li>
                                <a href="https://plus.google.com/+GandengtanganOrg">
                                    <i class="fa fa-google-plus"></i>
                                    <?php _e( 'Google+', 'blog' ); ?>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.linkedin.com/company/gandengtangan-org">
                                    <i class="fa fa-linkedin"></i>
                                    <?php _e( 'Linkedin', 'blog' ); ?>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.youtube.com/channel/UCZIyrf6JAgHoix80EgYhwEg">
                                    <i class="fa fa-youtube-play"></i>
                                    <?php _e( 'Youtube', 'blog' ); ?>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="midle-footer">
                <h3><?php _e( 'DILIPUT OLEH', 'blog' ); ?></h3>
                <ul>
                    <li>
                        <img src="https://www.gandengtangan.org/assets/img/media/techinasia.png">
                    </li>
                    <li>
                        <img src="https://www.gandengtangan.org/assets/img/media/dailysocial.png">
                    </li>
                    <li>
                        <img src="https://www.gandengtangan.org/assets/img/media/net.png">
                    </li>
                </ul>
            </div>
            <div class="bottom-footer">
                <br>
                <hr>
                <h2><?php _e( '© Copyright 2015, All Rights Reserved by', 'blog' ); ?><a href="https://www.gandengtangan.org" class="text-hover">
                        <?php _e( 'GandengTangan.org', 'blog' ); ?>
                    </a></h2>
            </div>
        </div>
    </footer>                  
    <?php wp_footer(); ?>
</body>         

<?php get_footer(); ?>