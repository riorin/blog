<!doctype html> 
<html style="height:100%;" <?php language_attributes(); ?>>
    <head> 
        <meta charset="<?php bloginfo( 'charset' ); ?>"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="keywords" content="pinegrow, blocks, bootstrap" />
        <meta name="description" content="My new website" />
        <link rel="shortcut icon" href="<?php echo esc_url( get_template_directory_uri() ); ?>/ico/favicon.png"> 
        <!-- Core CSS -->                  
        <!-- Style Library -->         
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->         
        <!--[if lt IE 9]>
      <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5shiv.js"></script>
      <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/respond.min.js"></script>
    <![endif]-->         
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
        <?php wp_head(); ?>
    </head>     
    <body data-spy="scroll" data-target="nav">
        <header class="pad-bottom90">
            <nav class="navbar navbar-fixed-top header">
                <div class="col-md-12">
                    <div class="navbar-header">
                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/logo_01.png" class="logo" />
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse1">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </div>
                    <div class="collapse navbar-collapse" id="navbar-collapse1">
                        <form class="navbar-form pull-left">
</form>
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <button type="button" class="btn btn-default">
                                    <?php _e( 'Label', 'blog' ); ?>
                                </button>
                                <button type="button" class="btn btn-default">
                                    <?php _e( 'Label', 'blog' ); ?>
                                </button>
                            </li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-bell"></i></a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="#">
                                            <span class="badge pull-right"><?php _e( '40', 'blog' ); ?></span>
                                            <?php _e( 'Link', 'blog' ); ?>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <span class="badge pull-right"><?php _e( '2', 'blog' ); ?></span>
                                            <?php _e( 'Link', 'blog' ); ?>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <span class="badge pull-right"><?php _e( '0', 'blog' ); ?></span>
                                            <?php _e( 'Link', 'blog' ); ?>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <span class="label label-info pull-right"><?php _e( '1', 'blog' ); ?></span>
                                            <?php _e( 'Link', 'blog' ); ?>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <span class="badge pull-right"><?php _e( '13', 'blog' ); ?></span>
                                            <?php _e( 'Link', 'blog' ); ?>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>                     
                </div>                 
            </nav>
        </header>
        <main>
            <div class="container main-single">
                <div class="col-md-9 blog-con">
                    <img src="https://unsplash.it/790/455/" />
                    <h3 id="title-blog"><?php _e( 'Column title', 'blog' ); ?></h3>
                    <small id="buplished"><?php _e( 'Someone famous in', 'blog' ); ?> <cite title="Source Title"><?php _e( 'Source Title', 'blog' ); ?></cite></small> 
                    <p id="p-content"><?php _e( 'Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.', 'blog' ); ?></p>
                    <small id="buplished"><?php _e( 'Someone famous in', 'blog' ); ?> <cite title="Source Title"><?php _e( 'Source Title', 'blog' ); ?></cite></small>
                    <hr />
                    <div class="col-md-4">
                        <div class="team-member min-height-xs-400px card-blog">
                            <?php the_post_thumbnail( 'large', array(
                                    'class' => 'img-responsive'
                            ) ); ?>
                            <div class="team-details">
                                <h4><?php the_title(); ?></h4>
                                <!-- /.social -->
                            </div>
                        </div>                         
                    </div>
                    <div class="col-md-4">
                        <div class="team-member min-height-xs-400px card-blog">
                            <?php the_post_thumbnail( 'large', array(
                                    'class' => 'img-responsive'
                            ) ); ?>
                            <div class="team-details">
                                <h4><?php the_title(); ?></h4>
                                <!-- /.social -->
                            </div>
                        </div>                         
                    </div>
                    <div class="col-md-4">
                        <div class="team-member min-height-xs-400px card-blog">
                            <?php the_post_thumbnail( 'large', array(
                                    'class' => 'img-responsive'
                            ) ); ?>
                            <div class="team-details">
                                <h4><?php the_title(); ?></h4>
                                <!-- /.social -->
                            </div>
                        </div>                         
                    </div>                     
                </div>
                <div class="col-md-3 sidebar">
                    <h3><h4><b><h5><?php _e( 'KOLOM PENCARIAN', 'blog' ); ?></h5></b></h4><hr /><div class="form-group"> 
</div></h3> 
                </div>
            </div>
        </main>
        <footer class="site-footer footer">
            <div class="container">
                <div class="top-footer">
                    <div class="row">
                        <div class="col-md-8">
                            <h2><?php _e( 'Tentang Gandeng Tangan', 'blog' ); ?></h2>
                            <p><?php _e( 'GandengTangan adalah wadah kolaborasi bagi pemilik usaha', 'blog' ); ?><br><?php _e( 'yang membutuhkan modal dengan publik yang tulus ingin membantu dengan', 'blog' ); ?><br><?php _e( 'memberikan pinjaman. GandengTangan hadir untuk', 'blog' ); ?><br><?php _e( 'menjembatani keduanya agar dapat bergandengan tangan untuk', 'blog' ); ?><br><?php _e( 'menciptakan dampak baik bagi Indonesia.', 'blog' ); ?></p>
                        </div>
                        <div class="col-md-2">
                            <h2><?php _e( 'Info Lain', 'blog' ); ?></h2>
                            <ul>
                                <li>
                                    <a href="#">
                                        <?php _e( 'Tentang kami', 'blog' ); ?>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" target="_blank">
                                        <?php _e( 'Blog', 'blog' ); ?>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <?php _e( 'Faq', 'blog' ); ?>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <?php _e( 'Privacy', 'blog' ); ?>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <?php _e( 'Syarat dan ketentuan', 'blog' ); ?>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <?php _e( 'Kontak', 'blog' ); ?>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-2">
                            <h2><?php _e( 'Follow Us', 'blog' ); ?></h2>
                            <ul>
                                <li>
                                    <a href="https://facebook.com/gandengtanganorg">
                                        <i class="fa fa-facebook"></i>
                                        <?php _e( 'facebook', 'blog' ); ?>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://twitter.com/gandeng_tangan">
                                        <i class="fa fa-twitter"></i>
                                        <?php _e( 'Twitter', 'blog' ); ?>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://instagram.com/gandengtangan">
                                        <i class="fa fa-instagram"></i>
                                        <?php _e( 'Instagram', 'blog' ); ?>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://plus.google.com/+GandengtanganOrg">
                                        <i class="fa fa-google-plus"></i>
                                        <?php _e( 'Google+', 'blog' ); ?>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/company/gandengtangan-org">
                                        <i class="fa fa-linkedin"></i>
                                        <?php _e( 'Linkedin', 'blog' ); ?>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.youtube.com/channel/UCZIyrf6JAgHoix80EgYhwEg">
                                        <i class="fa fa-youtube-play"></i>
                                        <?php _e( 'Youtube', 'blog' ); ?>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="midle-footer">
                    <h3><?php _e( 'DILIPUT OLEH', 'blog' ); ?></h3>
                    <ul>
                        <li>
                            <img src="https://www.gandengtangan.org/assets/img/media/techinasia.png">
                        </li>
                        <li>
                            <img src="https://www.gandengtangan.org/assets/img/media/dailysocial.png">
                        </li>
                        <li>
                            <img src="https://www.gandengtangan.org/assets/img/media/net.png">
                        </li>
                    </ul>
                </div>
                <div class="bottom-footer">
                    <br>
                    <hr>
                    <h2><?php _e( '© Copyright 2015, All Rights Reserved by', 'blog' ); ?><a href="https://www.gandengtangan.org" class="text-hover">
                            <?php _e( 'GandengTangan.org', 'blog' ); ?>
                        </a></h2>
                </div>
            </div>
        </footer>                           
        <?php wp_footer(); ?>
    </body>     
</html>
