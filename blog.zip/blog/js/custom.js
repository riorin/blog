// Mobile menu toggle 
        $(".menu-toggle").click(function(){
            $(".mobile-navigation").slideToggle(300);
        });